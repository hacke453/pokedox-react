const Colors = {
  brand_dark: "#212529",
  brand_green: "#13ce66",
  brand_pink: "#fe8bc4",
  brand_red: "#ff0000 ",
  brand_yellow: "#ffcb2c",
  brand_orange: "#fd7d24",

  darkest_gray: "#333333",
  darker_gray: "#666666",
  dark_gray: "#444444",
  brand_gray: "#c2c2c2",
  light_gray: "#dddddd",
  lighter_gray: "#eeeeee",
  lightest_gray: "#f2f2f2",
  card_gray: "#495057",
};

export default Colors;
